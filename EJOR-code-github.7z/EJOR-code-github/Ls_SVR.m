clear
clc
iVar = dir('NEISO-data-GEFCom2017/*.mat');
rng('default')
Y_Pred=[];
Y_Pred_top=[];
mape_best=zeros(8,1);
mse__best=zeros(8,1);
mape_best_top=zeros(8,1);
mse_best_top=zeros(8,1);

for cntOfExp = 1:length(iVar)
clearvars -except iVar cntOfExp mape_best mape_best_top mse_best_top mse__best Y_Pred Y_Pred_top
disp(['Exp ',num2str(cntOfExp),' of total Exp ',num2str(length(iVar)),'-',iVar(cntOfExp).name])
load(fullfile('NEISO-data-GEFCom2017',iVar(cntOfExp).name))
x_train=X;
y_train=y;
x_test=X1;
y_test=y1;
clear X y X1 y1
n_list=size(x_train,1);

%% lasso  特征重要性程度矩阵  添加维度

X_L_train=zeros(size(y_train,1),24);
for i=1:24
   X_L_train(i+1:end,i)= y_train(1:end-i);
end
[B, FitInfo] = lasso(X_L_train, y_train, 'CV', 5);  % 交叉验证
% 获取最佳模型的回归系数   确定增加维度信息
lasso_coeff = B(:, FitInfo.IndexMinMSE);
bb=abs(lasso_coeff);
[sortedData, sort_bb] = sort(bb,'descend');
T_hour=sort_bb(sortedData>0.1);

% 增加维度
Y_L=[y_train;y_test];
X_L=zeros(size(Y_L,1),24);
for i=1:24
   X_L(i+1:end,i)= Y_L(1:end-i);
end
X_q=[x_train;x_test];
X_q=[X_q,X_L(:,T_hour')];  
x_train=X_q(1:n_list,:);
x_test=X_q(n_list+1:end,:);

%% SM PK
% SW
X=x_train;
X11=[x_test(1:1416,:);x_test(end-744+1:end,:)];
X12=x_test(3625:5832,:);
X1=[X11;X12];
y=y_train;
y11=[y_test(1:1416);y_test(end-744+1:end)];
y12=y_test(3625:5832);
y1=[y11;y12];

%PK
n_list1=size(y11,1);
n_list2=size(y12,1);

Label_1=zeros(n_list1,1);
Label_1(1:n_list1) = ceil((1:n_list1) / 168)';  
L_1=1:ceil(n_list1/168);
Mean_1=zeros(length(L_1),1);
for ii=1:length(L_1)-1
    a=y11(Label_1==L_1(ii));
    Mean_1(ii,1)=mean(a);
end
[D1,H1]=max(Mean_1);

Label_2=zeros(n_list2,1);
Label_2(1:n_list2) = ceil((1:n_list2) / 168)'; 
L_2=1:ceil(n_list2/168);
Mean_2=zeros(length(L_2),1);
for ii=1:length(L_2)-1
    a=y12(Label_2==L_2(ii));
    Mean_2(ii,1)=mean(a);
end
[D2,H2]=max(Mean_2);

X2=[X11(Label_1==H1,:);X12(Label_2==H2,:)];
y2=[y11(Label_1==H1);y12(Label_2==H2)];

%%
MAPE=0;
for i=1:15   
    for j=1:15  
C=2^(i+9);  
epsilon=2^(j);

disp(['i= ',num2str(i),'    j= ',num2str(j)])
[w,b] = fl2svr_Ls(X,y,C);
 y_est=X1*w+b*ones(size(y1,1),1);
 Y_est(i,j,:)=y_est;
 MAPE_test(i,j)=mean(abs(y1-y_est)./y1);
 MSE_test(i,j)=mean((y1-y_est).^2);
 y_est1=X*w+b*ones(size(y,1),1);
 MAPE_train(i,j)=mean(abs(y-y_est1)./y);
  y_est2=X2*w+b*ones(size(y2,1),1);
 MAPE_test_top(i,j)=mean(abs(y2-y_est2)./y2);
 MSE_test_top(i,j)=mean((y2-y_est2).^2);
 Y_est2(i,j,:)=y_est2;
% MAPE(i)
    end
end
% Result = min(min(MAPE))
[C,I]=min(MAPE_train,[],2);
[C1,I1]=min(C);
MAPE_best=MAPE_test(I1,I(I1))
MSE_best=MSE_test(I1,I(I1))
MAPE_best_top=MAPE_test_top(I1,I(I1))
MSE_best_top=MSE_test_top(I1,I(I1))
y_pred_top=Y_est2(I1,I(I1),:);
y_pred=Y_est(I1,I(I1),:);

mape_best(cntOfExp)=MAPE_best;
mse__best(cntOfExp)=MSE_best;
mape_best_top(cntOfExp)=MAPE_best_top;
mse_best_top(cntOfExp)=MSE_best_top;
Y_Pred_top=[Y_Pred_top,y_pred_top]; 
Y_Pred=[Y_Pred,y_pred];

end
disp('Mission Completed!');