function [beta] = fuzzy_IRL1(x_train,y_train,tol)
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明
%   输入参数：tol 收敛条件

% 如果用户未输入设置的收敛误差tol
if nargin < 3
    % 如果用户没有提供 tol，设置默认值为1e-6
    tol = 1e-2;
elseif ~isnumeric(tol) || tol > 0.05
    % 如果 tol 存在但不符合条件，抛出错误
    error('第三个参数 tol 必须是小于等于 0.01 的数值！');
end
[n_train,m] = size(x_train);% 训练数据点个数
beta = ones(n_train,1); % 初始化训练数据权重
beta_matrix = []; % 每一代训练数据系数
error_list = []; % 每次迭代与上一次的变化度量
max_iterations = 10; % 最大迭代次数
iteration = 0; % 初始化迭代次数


while iteration < max_iterations % 当不满足最大迭代次数时
    
    iteration = iteration + 1;
    
    %%
    [n,d]=size(x_train);
    cvx_begin
        cvx_precision high;
        cvx_solver mosek
        variable u(d);
        variable c;
        variable epsilon(n) nonnegative;
        minimize(beta' * epsilon );
        subject to
               -epsilon <= y_train - (x_train * u + c*ones(n,1)) <= epsilon;
    cvx_end
    % 求β
    % 预测方程
    w = u;
    b = c;
    
    % 预测
    % 预测 y_train_pred
    y_train_pred = x_train*w + b*ones(n_train,1);
    
    % 更新权重
    dist=abs(y_train_pred-y_train);
    tempdist=zeros(size(dist,1),1);
    for i=1:size(dist,1)
        tempdist(i)=abs(dist(i)-median(dist));
    end
    tempdist=tempdist./median(tempdist);
    dist=tempdist;
    beta=zeros(size(dist,1),1);
    for kk=1:size(dist,1)
        beta(kk)=1/(dist(kk)+exp(dist(kk)));
    end
    
    beta_matrix = [beta_matrix,[u;c]];

    % 判断收敛条件
    if size(beta_matrix, 2) >= 2
        
        beta_new = beta_matrix(:, end);
        beta_old=beta_matrix(:, end-1);
        % 计算参数变化量
        delta = beta_new - beta_old;

        % 混合范数收敛条件（同时考虑绝对和相对变化）
        delta_norm = norm(delta);
        old_norm = norm(beta_old);

        if delta_norm / (1 + old_norm) < tol
            fprintf('Convergence within %d iterations\n', iteration);
            break;
        end
        
    end
end

end