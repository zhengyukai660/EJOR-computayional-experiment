function [w,b] =  fl2svr_Ls(X,y,C)
%% 线性LS-SVR求解函数
    % 输入参数:
    %   X : n×p 特征矩阵 (n=样本数, p=特征维数)
    %   y : n×1 响应向量
    %   gamma : 正则化系数 (控制模型复杂度)
    % 输出参数:
    %   w : p×1 权重向量
    %   b : 标量偏置项  
    [n, p] = size(X);
    % 构造增广矩阵 [X, ones(n,1)]
    X_aug = [X, ones(n,1)]; 
    
    % 构建正则化矩阵: diag([zeros(p,1); 0]) 不对偏置项正则化
    reg_matrix = diag([ones(p,1)/C; 0]); 
    
    % 解线性方程组 (XTX + reg_matrix)*theta = XT*y
    theta = (X_aug' * X_aug + reg_matrix) \ (X_aug' * y);
    
    w = theta(1:p);  % 提取权重
    b = theta(p+1);  % 提取偏置
end

