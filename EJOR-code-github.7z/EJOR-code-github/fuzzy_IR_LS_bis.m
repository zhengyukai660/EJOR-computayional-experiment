function [gamma]=fuzzy_IR_LS_bis(X,y)
%% 数据归一化

% m = size(X);
% mins = min(X);
% maxs = max(X);
% for i = 1:m
%     X(i,:) = (X(i,:) - mins) ./ (maxs - mins);
% end
%% 初始L2回归加权
u = robustfit(X,y,'bisquare');
w=u(2:end);
b=u(1);
y_11=X*w+b*ones(size(y,1),1);
dist=abs(y_11-y);
tempdist=zeros(size(dist,1),1);
for i=1:size(dist,1)
    tempdist(i)=abs(dist(i)-median(dist));
end
tempdist=tempdist./median(tempdist);
dist=tempdist;
gamma=zeros(size(dist,1),1);
for kk=1:size(dist,1)
    gamma(kk)=1/(dist(kk)+exp(dist(kk)));
end


