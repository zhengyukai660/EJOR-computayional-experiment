clear
clc
iVar = dir('NEISO-data-GEFCom2017/*.mat');
rng('default')
Y_Pred=[];
Y_Pred_top=[];
mape_best=zeros(8,1);
mse__best=zeros(8,1);
mape_best_top=zeros(8,1);
mse_best_top=zeros(8,1);

for cntOfExp = 1:length(iVar)
clearvars -except iVar cntOfExp mape_best mape_best_top mse_best_top mse__best Y_Pred Y_Pred_top
disp(['Exp ',num2str(cntOfExp),' of total Exp ',num2str(length(iVar))])
load(fullfile('NEISO-data-GEFCom2017',iVar(cntOfExp).name))

x_train=X;
y_train=y;
x_test=X1;
y_test=y1;
clear X y X1 y1
n_list=size(x_train,1);

%% lasso 
X_L_train=zeros(size(y_train,1),24);
for i=1:24
   X_L_train(i+1:end,i)= y_train(1:end-i);
end
[B, FitInfo] = lasso(X_L_train, y_train, 'CV', 5);  % 交叉验证
lasso_coeff = B(:, FitInfo.IndexMinMSE);
bb=abs(lasso_coeff);
[sortedData, sort_bb] = sort(bb,'descend');
T_hour=sort_bb(sortedData>0.1);

Y_L=[y_train;y_test];
X_L=zeros(size(Y_L,1),24);
for i=1:24
   X_L(i+1:end,i)= Y_L(1:end-i);
end
X_q=[x_train;x_test];
X_q=[X_q,X_L(:,T_hour')];  
x_train=X_q(1:n_list,:);
x_test=X_q(n_list+1:end,:);

%% SM PK
% 冬夏
X=x_train;
X11=[x_test(1:1416,:);x_test(end-744+1:end,:)];
X12=x_test(3625:5832,:);
X1=[X11;X12];
y=y_train;
y11=[y_test(1:1416);y_test(end-744+1:end)];
y12=y_test(3625:5832);
y1=[y11;y12];

%冬夏双高峰周
n_list1=size(y11,1);
n_list2=size(y12,1);

Label_1=zeros(n_list1,1);
Label_1(1:n_list1) = ceil((1:n_list1) / 168)'; 
Mean_1=zeros(length(L_1),1);
for ii=1:length(L_1)-1
    a=y11(Label_1==L_1(ii));
    Mean_1(ii,1)=mean(a);
end
[D1,H1]=max(Mean_1);

Label_2=zeros(n_list2,1);
Label_2(1:n_list2) = ceil((1:n_list2) / 168)'; 
L_2=1:ceil(n_list2/168);
Mean_2=zeros(length(L_2),1);
for ii=1:length(L_2)-1
    a=y12(Label_2==L_2(ii));
    Mean_2(ii,1)=mean(a);
end
[D2,H2]=max(Mean_2);

X2=[X11(Label_1==H1,:);X12(Label_2==H2,:)];
y2=[y11(Label_1==H1);y12(Label_2==H2)];

%% 预测结果

net = newff(X',y',22,{'logsig','purelin'});
net= train(net,X',y');

y_est = net(X1');
mape_best(cntOfExp) = mean(abs((y1 - y_est) ./ y1))
mse__best(cntOfExp)=mean((y1-y_est).^2)
Y_Pred=[Y_Pred,y_est];


y_est2 =net(X2');
mape_best_top(cntOfExp)=mean(abs(y2-y_est2)./y2)
mse_best_top(cntOfExp)=mean((y2-y_est2).^2)
Y_Pred_top=[Y_Pred_top,y_est2]; 


save('./GEF2017_MLR-ramp-wu','mape_best','mape_best_top','mse_best_top','mse__best','Y_Pred','Y_Pred_top');
% save('./GEF2017_MLR-PCVF-08','mape_best','mape_best_top','mse_best_top','mse__best','Y_Pred','Y_Pred_top');
% save('./GEF2017_MLR-SPV-12','mape_best','mape_best_top','mse_best_top','mse__best','Y_Pred','Y_Pred_top');

end
% disp(aa)
% MPE_opt=median(MPE,1);
%     mpe1=mean(MPE_opt(1:10));
%      mpe2=mean(MPE_opt(11:20));
%           mpe3=mean(MPE_opt(21:30));
%     mpe4=mean(MPE_opt(31:40));
%      mpe5=mean(MPE_opt(41:50));
%           mpe6=mean(MPE_opt(51:60));
% %             mpe7=mean(MPE_opt(61:70));
% %                 mpe8=mean(MPE_opt(71:80));
% %      mpe9=mean(MPE_opt(81:90));
% %           mpe10=mean(MPE_opt(91:100));
% %             mpe11=mean(MPE_opt(101:end));
%           
%               MAPE_opt=median(MAPE,1);
%                   mape1=mean(MAPE_opt(1:10));
%      mape2=mean(MAPE_opt(11:20));
%           mape3=mean(MAPE_opt(21:30));
%     mape4=mean(MAPE_opt(31:40));
%      mape5=mean(MAPE_opt(41:50));
%           mape6=mean(MAPE_opt(51:60));
          

%                       mape7=mean(MAPE_opt(61:70));    
%                       mape8=mean(MAPE_opt(71:80));
%      mape9=mean(MAPE_opt(81:90));
%           mape10=mean(MAPE_opt(91:100));
%                        mape11=mean(MAPE_opt(101:end));