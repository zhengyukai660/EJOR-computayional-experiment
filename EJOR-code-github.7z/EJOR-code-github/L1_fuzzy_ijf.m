function [gamma]=L1_fuzzy_ijf(X,y)
%% 数据归一化

m = size(X);
mins = min(X);
maxs = max(X);
for i = 1:m
    X(i,:) = (X(i,:) - mins) ./ (maxs - mins);
end
%% 初始L1回归 
[n,d]=size(X);
cvx_begin
	cvx_precision high;
    cvx_solver sedumi
    variable u(d);
    variable c;
%     variable ksi(n) nonnegative;
    variable epsilon(n) nonnegative;
    minimize(ones(1,n) * epsilon );
    subject to
           -epsilon <= y - (X * u + c*ones(n,1)) <= epsilon;
cvx_end
w=u;
b=c;
%%
y_11=X*w+b(1)*ones(size(y,1),1);
dist=abs(y_11-y);
tempdist=zeros(size(dist,1),1);
for i=1:size(dist,1)
    tempdist(i)=abs(dist(i)-median(dist));
end
tempdist=tempdist./median(tempdist);
dist=tempdist;

gamma=zeros(size(dist,1),1);
for kk=1:size(dist,1)
    gamma(kk)=exp(-dist(kk));
end


