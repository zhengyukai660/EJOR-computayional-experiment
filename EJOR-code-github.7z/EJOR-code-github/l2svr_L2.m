function [w,b] =  l2svr_L2(X,y,C,epsilon)
%m: # of features
%X: n0*m matrix, which records n0 input points
%y: associated output value of X
%C: the cost of error
%epsilon: width of the tube
%w,b: parameters of separating hyperplane
n0=size(X,1);
m=size(X,2);

H=zeros(m+1+n0);
H(1:m,1:m)=eye(m);
H(m+2:m+1+n0,m+2:m+1+n0)=2*C*eye(n0);
% H(m+2:m+1+n0,m+2:m+1+n0)=2*C;

B1=[-X,-ones(n0,1),-eye(n0)];
B2=[X,ones(n0,1),-eye(n0)];
A=[B1;B2];
b_b=[epsilon*ones(n0,1)-y;epsilon*ones(n0,1)+y];
% LB=-Inf*ones(m+1+2*n0,1);
% UB=Inf*ones(m+1+2*n0,1);
H1=sparse(H);
A1=sparse(A);
b_b1=sparse(b_b);
clear H A b_b B1 B2
 opts = optimoptions('quadprog','Algorithm','interior-point-convex','Display','off');
%  opts = mskoptimset('Algorithm', 'interior-point-convex', 'Display', 'off');
  z1 = quadprog(H1,[],A1,b_b1,[],[],[],[],[],opts);
  disp(z1)
  disp(size(z1))
  w=z1(1:m,1);
  b=z1(m+1);
end