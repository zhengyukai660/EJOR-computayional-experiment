function [w_value,b_value] = RAL1_L2SVR_train(X,y,C,delta,alpha,mu,beta)

[n,d]=size(X);
M = 1e4;      % 大M常数
% 定义优化变量
w = sdpvar(d, 1);
b = sdpvar(1);
xi = sdpvar(n, 1);
z = binvar(n, 1); % 二元变量
% 定义辅助变量
epsilon = sdpvar(n, 1); 

% xi = sdpvar(n,1,'full');  
% z = binvar(n,1,'full');  
% epsilon = sdpvar(n,1,'full');

% mu=ones(n,1)*0.5;
% beta=ones(n,1)*0.5;

 
% 重构目标函数与约束
objective = 0.5*(w'*w) + C*sum(epsilon);  
constraints = [];  
for i = 1:n  
    % 主约束（原模型约束保留）
    constraints = [constraints, delta + xi(i) >= y(i) - X(i,:)*w - b];  
    constraints = [constraints, y(i) - X(i,:)*w - b >= -delta - xi(i)];  
    % 分段损失项线性化约束
    constraints = [constraints, epsilon(i) >= (beta(i)*alpha*y(i))^2 + mu(i)*(xi(i) - alpha*y(i)) - M*(1-z(i))];  
    constraints = [constraints, epsilon(i) >= (beta(i)*xi(i))^2 - M*z(i)];  
    % 其他约束（如ξ_i界限、二元变量约束）
    constraints = [constraints, xi(i) <= alpha*y(i) + M*z(i)];  
    constraints = [constraints, xi(i) >= alpha*y(i) - M*(1-z(i))];  
    constraints = [constraints, xi(i) >= 0, z(i) >= 0, z(i) <= 1];  
end  
disp('constraints-completed')
% 求解器参数设置
% options = sdpsettings('solver', 'gurobi',...
%      'gurobi.FeasibilityTol', 1e-6, ...
%     'gurobi.OptimalityTol', 1e-5, ...
%     'gurobi.QCPDual', 1);  

options = sdpsettings('solver', 'gurobi',...
    'gurobi.QCPDual', 1);  

% 求解
diagnosis = optimize(constraints, objective, options);

% 结果提取与展示
if diagnosis.problem == 0
    w_value = value(w);
    b_value = value(b);
    disp('优化成功！');
else
    error('求解失败: %s', diagnosis.info);
end
end
